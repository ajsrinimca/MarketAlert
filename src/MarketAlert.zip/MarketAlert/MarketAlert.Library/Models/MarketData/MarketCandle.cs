namespace MarketAlert.Library.Models.MarketData;

public class MarketCandle
{
    public int SymbolId { get; set; }

    public long Token { get; set; }

    public DateTime Date { get; set; }

    public decimal Open { get; set; }

    public decimal High { get; set; }

    public decimal Low { get; set; }

    public decimal Close { get; set; }

    public long Volume { get; set; }
}