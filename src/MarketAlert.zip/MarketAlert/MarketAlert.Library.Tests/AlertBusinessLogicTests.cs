using MarketAlert.Library.Configuration;
using MarketAlert.Library.Caching;
using MarketAlert.Library.Models.Alerts;
using MarketAlert.Library.Models.MarketData;
using MarketAlert.Library.Models.MarketStatus;
using MarketAlert.Library.Repositories;
using MarketAlert.Library.Services.Alerts.Detection;
using MarketAlert.Library.Services.Alerts.Orchestration;
using MarketAlert.Library.Services.MarketData;
using MarketAlert.Library.Services.MarketStatus;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Xunit;

namespace MarketAlert.Library.Tests;

public sealed class AlertBusinessLogicTests
{
    [Fact]
    public void OutsideBar_UsesStrictRangeExtensionAndCandleDirection()
    {
        var detector = new OutsideBarDetectionService(
            Options.Create(new OutsideBarSettings()),
            NullLogger<OutsideBarDetectionService>.Instance);
        var previous = Candle(10, 12, 8, 10);

        var bullish = detector.Detect("ABC", [previous, Candle(9, 13, 7, 12)], false);
        var equalHigh = detector.Detect("ABC", [previous, Candle(9, 12, 7, 11)], false);

        Assert.True(bullish.IsPatternDetected);
        Assert.Equal("Bullish", bullish.Direction);
        Assert.False(equalHigh.IsPatternDetected);
    }

    [Fact]
    public void Triangle_RequiresFlatResistanceAndProgressivelyRisingLows()
    {
        var swings = new FixedSwingPoints(
            [Swing(5, 110), Swing(15, 110.5m)],
            [Swing(9, 90), Swing(19, 95)]);
        var detector = new TriangleDetectionService(swings, Options.Create(TriangleSettings()));

        var result = detector.Detect("ABC", Candles(30));

        Assert.True(result.IsPatternDetected);
        Assert.Equal("AscendingTriangle", result.Pattern);
    }

    [Fact]
    public void SymmetricalTriangle_RequiresConvergingSwingHighsAndLows()
    {
        var swings = new FixedSwingPoints(
            [Swing(4, 110), Swing(10, 108)],
            [Swing(6, 90), Swing(12, 92)]);
        var detector = new SymmetricalTriangleDetectionService(swings, Options.Create(TriangleSettings()));
        var candles = Candles(20);
        candles[^1].Close = 106m;

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Bullish", result.BreakoutDirection);
        Assert.True(result.UpperTrendline > result.LowerTrendline);
    }

    [Fact]
    public void FlagPennant_RequiresImpulseAndRetracementWithinFiftyPercent()
    {
        var candles = Candles(10);
        for (var i = 0; i < 5; i++)
        {
            var close = 100m + 2m * i;
            candles[i] = Candle(close - 1, close + 1, close - 2, close);
        }

        for (var i = 0; i < 5; i++)
        {
            var close = 109m - i;
            candles[i + 5] = Candle(close + 1, close + 2, close - 1, close);
        }

        var result = new FlagPennantDetectionService().Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Bull Flag", result.PatternType);
        Assert.InRange(result.PoleChangePercentage, 8m, 20m);
        Assert.InRange(result.RetracementPercentage, 0m, 50m);
    }

    [Fact]
    public void RectangleBreakout_RequiresValidBoxAndCloseOutsideIt()
    {
        var box = Enumerable.Range(0, 20).Select(_ => Candle(105, 110, 100, 105)).ToList();
        var detector = new RectangleBreakoutDetectionService();

        var breakout = detector.Detect("ABC", [.. box, Candle(105, 112, 100, 111)]);
        var insideBox = detector.Detect("ABC", [.. box, Candle(105, 110, 100, 105)]);

        Assert.True(breakout.IsConsolidationDetected);
        Assert.True(breakout.IsPatternDetected);
        Assert.Equal("Up", breakout.BreakoutDirection);
        Assert.True(insideBox.IsConsolidationDetected);
        Assert.False(insideBox.IsPatternDetected);
    }

    [Fact]
    public void RoundingBottom_RejectsInsufficientLookback()
    {
        var detector = new RoundingBottomDetectionService(
            Options.Create(new RoundingBottomSettings { LookbackCandles = 90 }),
            NullLogger<RoundingBottomDetectionService>.Instance);

        Assert.False(detector.Detect("ABC", Candles(89)).IsPatternDetected);
    }

    [Fact]
    public void RoundingBottom_RequiresFallingFlatAndRisingSmaWithMiddleLow()
    {
        var candles = Candles(90);
        for (var i = 0; i < candles.Count; i++)
        {
            var close = i < 30
                ? 120m - 0.15m * i
                : i < 60
                    ? 115.65m
                    : 115.65m + 0.15m * (i - 59);
            candles[i].Open = close;
            candles[i].Close = close;
            candles[i].High = close + 1;
            candles[i].Low = close - 1;
        }
        candles[45].Low = 80;

        var detector = new RoundingBottomDetectionService(
            Options.Create(new RoundingBottomSettings
            {
                LookbackCandles = 90,
                MiddleSmaFlatnessPercent = 2m
            }),
            NullLogger<RoundingBottomDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal(45, result.LowestLowIndex);
    }

    [Fact]
    public void IslandReversal_RequiresGapAndConfirmationBeyondIsland()
    {
        var detector = new IslandReversalDetectionService(
            Options.Create(new IslandReversalSettings()),
            NullLogger<IslandReversalDetectionService>.Instance);
        var candles = new List<MarketCandle>
        {
            Candle(95, 100, 90, 96),
            Candle(86, 89, 84, 87),
            Candle(94, 97, 92, 96)
        };

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Bottom Island", result.PatternType);
        Assert.Equal("Gap Down", result.GapType);
    }

    [Fact]
    public async Task BlockBulkDeal_AppliesConfiguredValueAndListedShareThresholds()
    {
        var repository = new FakeBlockBulkDealRepository(
            new DateOnly(2026, 10, 26),
            [
                new BlockBulkDealRow
                {
                    Ticker = "ABC", DealCategory = "BLOCK", ClientName = "Fund A",
                    Quantity = 250_000, TradePrice = 1_000
                },
                new BlockBulkDealRow
                {
                    Ticker = "XYZ", DealCategory = "BULK", ClientName = "Fund B",
                    Quantity = 51_000, TradePrice = 10
                }
            ],
            new Dictionary<string, decimal> { ["XYZ"] = 10_000_000m });
        var settings = new BlockBulkDealSettings
        {
            BlockDealMinimumValueInr = 250_000_000m,
            BulkDealThresholdPercent = 0.5m,
            BlockRowsPrequalifiedBySource = true
        };
        var service = new BlockBulkDealAlertService(
            repository,
            marketSymbolService: null!,
            marketStatusService: null!,
            liveMarketDataService: null!,
            Options.Create(settings),
            NullLogger<BlockBulkDealAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", null, false);

        Assert.Equal(2, response.Data.Count);
        Assert.Contains(response.Data, item => item.AlertType == "BlockDeal" && item.DealValue == 250_000_000m);
        Assert.Contains(response.Data, item => item.AlertType == "BulkDeal" && item.BulkPercent == 0.51m);
    }

    [Fact]
    public async Task BlockBulkDeal_LiveRequestUsesBrokerTradingDate()
    {
        var brokerDate = new DateOnly(2026, 10, 28);
        var repository = new FakeBlockBulkDealRepository(
            brokerDate, [], new Dictionary<string, decimal>());
        var service = new BlockBulkDealAlertService(
            repository,
            marketSymbolService: null!,
            new OpenMarketStatusService(),
            new FixedLiveMarketDataService(new LiveMarketResponse
            {
                LastUpdatedTime = brokerDate.ToDateTime(new TimeOnly(14, 30))
            }),
            Options.Create(new BlockBulkDealSettings()),
            NullLogger<BlockBulkDealAlertService>.Instance);

        await service.GetAlertsAsync("NSE", null, includeLive: true);

        Assert.Equal(brokerDate, repository.RequestedDealDate);
    }

    [Fact]
    public async Task BlockBulkDeal_FallsBackToPreviousStoredDateWhenBrokerDateHasNoDealsYet()
    {
        var storedDate = new DateOnly(2026, 10, 27);
        var repository = new FakeBlockBulkDealRepository(
            storedDate,
            [new BlockBulkDealRow
            {
                Ticker = "ABC", DealCategory = "BLOCK", ClientName = "Fund A",
                Quantity = 250_000, TradePrice = 1_000
            }],
            new Dictionary<string, decimal>());
        var service = new BlockBulkDealAlertService(
            repository,
            marketSymbolService: null!,
            new OpenMarketStatusService(),
            new FixedLiveMarketDataService(new LiveMarketResponse
            {
                LastUpdatedTime = new DateOnly(2026, 10, 28).ToDateTime(new TimeOnly(14, 30))
            }),
            Options.Create(new BlockBulkDealSettings
            {
                BlockDealMinimumValueInr = 250_000_000m,
                BlockRowsPrequalifiedBySource = true
            }),
            NullLogger<BlockBulkDealAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", null, includeLive: true);

        Assert.Equal(storedDate.ToString("yyyy-MM-dd"), response.Ltd);
        Assert.Contains(response.Data, result => result.AlertType == "BlockDeal");
        Assert.All(response.Data, result => Assert.False(result.IsProvisional));
        Assert.Equal(storedDate, repository.RequestedDealDate);
    }

    [Fact]
    public void HeadAndShoulders_RequiresOrderedPivotsNecklineAndPriorTrend()
    {
        var candles = Candles(110);
        SetTrend(candles, 10, 30, rising: false);
        var swings = new FixedSwingPoints(
            [Swing(36, 105), Swing(45, 106)],
            [Swing(32, 100), Swing(40, 90), Swing(50, 101)]);
        var detector = new HeadAndShouldersDetectionService(
            swings,
            Options.Create(new SwingPatternSettings()),
            NullLogger<HeadAndShouldersDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Inverse Head & Shoulders", result.PatternType);
        Assert.Equal("Downtrend", result.PriorTrend);
    }

    [Fact]
    public void InverseHeadAndShoulders_AppliesHeadAndShoulderFormulaBoundaries()
    {
        HeadAndShouldersResult Detect(decimal head, decimal rightShoulder)
        {
            var candles = Candles(110);
            SetTrend(candles, 10, 30, rising: false);
            var swings = new FixedSwingPoints(
                [Swing(36, 105), Swing(45, 106)],
                [Swing(32, 100), Swing(40, head), Swing(50, rightShoulder)]);
            var detector = new HeadAndShouldersDetectionService(
                swings,
                Options.Create(new SwingPatternSettings()),
                NullLogger<HeadAndShouldersDetectionService>.Instance);

            return detector.Detect("ABC", candles);
        }

        Assert.True(Detect(head: 97m, rightShoulder: 103m).IsPatternDetected);
        Assert.False(Detect(head: 97.01m, rightShoulder: 100m).IsPatternDetected);
        Assert.False(Detect(head: 97m, rightShoulder: 103.01m).IsPatternDetected);
    }

    [Fact]
    public void HeadAndShouldersTop_RequiresHigherHeadAndPriorUptrend()
    {
        var candles = Candles(110);
        SetTrend(candles, 10, 30, rising: true);
        var swings = new FixedSwingPoints(
            [Swing(32, 100), Swing(40, 110), Swing(50, 101)],
            [Swing(36, 95), Swing(45, 94)]);
        var detector = new HeadAndShouldersDetectionService(
            swings,
            Options.Create(new SwingPatternSettings()),
            NullLogger<HeadAndShouldersDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Head & Shoulders Top", result.PatternType);
        Assert.Equal("Uptrend", result.PriorTrend);
    }

    [Fact]
    public void HeadAndShouldersTop_AppliesHeadAndShoulderFormulaBoundaries()
    {
        HeadAndShouldersResult Detect(decimal head, decimal rightShoulder)
        {
            var candles = Candles(110);
            SetTrend(candles, 10, 30, rising: true);
            var swings = new FixedSwingPoints(
                [Swing(32, 100), Swing(40, head), Swing(50, rightShoulder)],
                [Swing(36, 95), Swing(45, 94)]);
            var detector = new HeadAndShouldersDetectionService(
                swings,
                Options.Create(new SwingPatternSettings()),
                NullLogger<HeadAndShouldersDetectionService>.Instance);

            return detector.Detect("ABC", candles);
        }

        Assert.True(Detect(head: 106.09m, rightShoulder: 103m).IsPatternDetected);
        Assert.False(Detect(head: 106.08m, rightShoulder: 103m).IsPatternDetected);
        Assert.False(Detect(head: 106.296m, rightShoulder: 103.2m).IsPatternDetected);
    }

    [Fact]
    public void DoubleTopBottom_RequiresMatchingPeaksIntermediateMoveAndPriorTrend()
    {
        var candles = Candles(80);
        SetTrend(candles, 10, 30, rising: true);
        candles[37].Low = 94;
        var swings = new FixedSwingPoints([Swing(30, 100), Swing(45, 100.5m)], []);
        var detector = new DoubleTopBottomDetectionService(
            swings,
            Options.Create(new SwingPatternSettings()),
            NullLogger<DoubleTopBottomDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Double Top", result.PatternType);
        Assert.Equal(15, result.DistanceCandles);
    }

    [Fact]
    public void DoubleBottom_RequiresMatchingTroughsIntermediateRiseAndPriorDowntrend()
    {
        var candles = Candles(80);
        SetTrend(candles, 10, 30, rising: false);
        candles[37].High = 106;
        var swings = new FixedSwingPoints(
            [],
            [Swing(30, 100), Swing(45, 100.5m)]);
        var detector = new DoubleTopBottomDetectionService(
            swings,
            Options.Create(new SwingPatternSettings()),
            NullLogger<DoubleTopBottomDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Double Bottom", result.PatternType);
        Assert.Equal("Bullish", result.Direction);
    }

    [Fact]
    public void CupHandle_RequiresRoundedCupAndShallowHandle()
    {
        var candles = Candles(22);
        foreach (var index in Enumerable.Range(8, 5))
        {
            candles[index].Low = 80;
        }

        foreach (var index in new[] { 19, 20, 21 })
        {
            candles[index].Low = 91;
        }

        var settings = new CupHandleSettings
        {
            MinimumCupCandles = 15,
            MaximumCupCandles = 50,
            MinimumHandleCandles = 2,
            MaximumHandleCandles = 5,
            RoundedBottomCandles = 5,
            RoundedBottomTolerancePercent = 3
        };
        var detector = new CupHandleDetectionService(
            new FixedSwingPoints([Swing(2, 100), Swing(18, 100)], []),
            Options.Create(settings),
            Options.Create(new SwingPatternSettings()),
            NullLogger<CupHandleDetectionService>.Instance);

        var result = detector.Detect("ABC", candles);

        Assert.True(result.IsPatternDetected);
        Assert.Equal("Cup & Handle", result.PatternType);
        Assert.InRange(result.HandlePullbackPercent, 0m, 12m);
    }

    [Fact]
    public async Task ShortCovering_ReportsIncompleteWithoutTwoComparableEodSessions()
    {
        var service = new ShortCoveringAlertService(
            new FakeLongUnwindingRepository(
                new LongUnwindingEodSnapshot(null, null, ["NIFTY", "BANKNIFTY"], [])),
            Options.Create(new ShortCoveringSettings()),
            NullLogger<ShortCoveringAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", "Nifty", false);

        var result = Assert.Single(response.Data);
        Assert.Equal("incomplete_data", result.EvaluationStatus);
        Assert.Equal(0, response.Summary.Detected);
        Assert.Contains("trading dates", result.EvaluationMessage, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task ShortCovering_AlertsOnlyWhenIndexPriceRisesAndCombinedOiFalls()
    {
        var currentDate = new DateOnly(2026, 11, 4);
        var previousDate = new DateOnly(2026, 11, 3);
        var snapshot = new LongUnwindingEodSnapshot(
            currentDate,
            previousDate,
            ["NIFTY", "BANKNIFTY"],
            [
                new("NIFTY", currentDate, 24_500m, 15_045_095m),
                new("NIFTY", previousDate, 24_400m, 16_000_000m),
                new("BANKNIFTY", currentDate, 52_000m, 8_000_000m),
                new("BANKNIFTY", previousDate, 52_100m, 9_000_000m)
            ]);
        var service = new ShortCoveringAlertService(
            new FakeLongUnwindingRepository(snapshot),
            Options.Create(new ShortCoveringSettings
            {
                SupportedGroups = ["Nifty", "Bank Nifty", "Nifty", "BankNifty"]
            }),
            NullLogger<ShortCoveringAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", null, includeLive: false);

        Assert.Equal(2, response.Data.Count);
        Assert.Equal(2, response.Data.Select(result => result.Ticker).Distinct().Count());
        Assert.True(response.Data.Single(result => result.Ticker == "NIFTY").IsPatternDetected);
        Assert.False(response.Data.Single(result => result.Ticker == "BANKNIFTY").IsPatternDetected);
        Assert.Equal(15_045_095m, response.Data.Single(result => result.Ticker == "NIFTY").CurrentCombinedOI);
        Assert.Equal(2, response.Summary.Processed);
        Assert.Equal(1, response.Summary.Detected);
    }

    [Fact]
    public void InsideBarNr7Nr4_MatchesNestedCandleAndMinimumFourAndSevenCandleRanges()
    {
        var candles = Candles(7);
        var ranges = new[] { 8m, 7m, 6m, 5m, 4m, 3m, 1m };
        for (var i = 0; i < candles.Count; i++)
        {
            candles[i] = Candle(100, 100 + ranges[i], 100, 100 + ranges[i] / 2);
        }

        candles[^2].High = 104;
        candles[^2].Low = 98;
        candles[^1].High = 103;
        candles[^1].Low = 99;
        candles[^1].Close = 101;

        var detector = new InsideBarNr7Nr4DetectionService(
            NullLogger<InsideBarNr7Nr4DetectionService>.Instance);
        var result = detector.Detect("ABC", candles, false);

        Assert.Contains("InsideBar", result.MatchedPatterns);
        Assert.Contains("NR7", result.MatchedPatterns);
        Assert.Contains("NR4", result.MatchedPatterns);
    }

    [Fact]
    public async Task LongUnwinding_ReportsIncompleteUntilComparablePriceAndOiDataExists()
    {
        var service = new LongUnwindingAlertService(
            new FakeLongUnwindingRepository(
                new LongUnwindingEodSnapshot(null, null, ["ABC", "XYZ"], [])),
            Options.Create(new LongUnwindingSettings()),
            NullLogger<LongUnwindingAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", null, false);

        Assert.Equal("incomplete_data", response.Summary.EvaluationStatus);
        Assert.Equal(2, response.Summary.TotalFnoUnderlyings);
        Assert.Equal(2, response.Data.Count);
        Assert.All(
            response.Data,
            result => Assert.Equal("incomplete_data", result.EvaluationStatus));
        Assert.Equal(0, response.Summary.Detected);
    }

    [Fact]
    public async Task LongUnwinding_UsesFullUniverseAndAlertsAtThirtyPercent()
    {
        var currentDate = new DateOnly(2026, 11, 4);
        var previousDate = new DateOnly(2026, 11, 3);
        var tickers = Enumerable.Range(1, 10).Select(index => $"STOCK{index}").ToList();
        var observations = new List<LongUnwindingEodObservation>();

        for (var i = 0; i < tickers.Count; i++)
        {
            var isLongUnwinding = i < 3;
            observations.Add(new LongUnwindingEodObservation(
                tickers[i], currentDate, isLongUnwinding ? 90m : 110m, isLongUnwinding ? 90m : 110m));
            observations.Add(new LongUnwindingEodObservation(
                tickers[i], previousDate, 100m, 100m));
        }

        var snapshot = new LongUnwindingEodSnapshot(
            currentDate,
            previousDate,
            tickers,
            observations);
        var service = new LongUnwindingAlertService(
            new FakeLongUnwindingRepository(snapshot),
            Options.Create(new LongUnwindingSettings()),
            NullLogger<LongUnwindingAlertService>.Instance);

        var response = await service.GetAlertsAsync("NSE", null, includeLive: false);

        Assert.Equal(10, response.Data.Count);
        Assert.Equal("evaluated", response.Summary.EvaluationStatus);
        Assert.Equal(10, response.Summary.TotalFnoUnderlyings);
        Assert.Equal(10, response.Summary.EvaluatedUnderlyings);
        Assert.Equal(3, response.Summary.LongUnwindingCount);
        Assert.Equal(30m, response.Summary.LuPercent);
        Assert.True(response.Summary.MarketLevelAlertDetected);
        Assert.Equal(3, response.Summary.Detected);
        Assert.Equal(3, response.Data.Count(result => result.IsPatternDetected));
    }

    [Fact]
    public async Task MarketData_UsesBrokerDateAndPreviousNMinusOneUniqueSessions()
    {
        var today = DateTime.Today;
        var history = new List<MarketCandle>
        {
            CandleOn(today.AddDays(-3)),
            CandleOn(today.AddDays(-2)),
            CandleOn(today.AddDays(-1))
        };
        var service = CreateMarketDataService(
            history,
            new LiveMarketResponse
            {
                LastUpdatedTime = today.AddHours(11),
                Quotes = [new LiveQuote { Ticker = "ABC", Open = 100, High = 105, Low = 99, LastPrice = 103, Volume = 1 }]
            });

        var result = Assert.Single(await service.GetMarketDataAsync("NSE", ["ABC"], true, 3));

        Assert.False(result.IsSkipped);
        Assert.True(result.IsLive);
        Assert.Equal(3, result.Candles.Count);
        Assert.Equal(today, result.Candles[^1].Date.Date);
        Assert.Equal(103, result.Candles[^1].Close);
        Assert.Equal(result.Candles.Count, result.Candles.Select(candle => candle.Date.Date).Distinct().Count());
    }

    [Fact]
    public async Task MarketData_UsesPreviousSessionWhenBrokerTimestampIsStale()
    {
        var today = DateTime.Today;
        var history = new List<MarketCandle>
        {
            CandleOn(today.AddDays(-4)),
            CandleOn(today.AddDays(-3)),
            CandleOn(today.AddDays(-2)),
            CandleOn(today.AddDays(-1))
        };
        var service = CreateMarketDataService(
            history,
            new LiveMarketResponse { LastUpdatedTime = today.AddDays(-1).AddHours(15) });

        var result = Assert.Single(await service.GetMarketDataAsync("NSE", ["ABC"], true, 3));

        Assert.False(result.IsSkipped);
        Assert.False(result.IsLive);
        Assert.Equal(3, result.Candles.Count);
        Assert.Equal(today.AddDays(-1), result.Candles[^1].Date.Date);
    }

    [Fact]
    public async Task MarketData_DeduplicatesDailyHistoryBeforeBuildingCurrentWindow()
    {
        var today = DateTime.Today;
        var duplicate = CandleOn(today.AddDays(-2));
        duplicate.Close = 101;
        var history = new List<MarketCandle>
        {
            CandleOn(today.AddDays(-3)),
            CandleOn(today.AddDays(-2)),
            duplicate,
            CandleOn(today.AddDays(-1))
        };
        var service = CreateMarketDataService(
            history,
            new LiveMarketResponse
            {
                LastUpdatedTime = today.AddHours(12),
                Quotes = [new LiveQuote { Ticker = "ABC", Open = 100, High = 105, Low = 99, LastPrice = 103, Volume = 10 }]
            });

        var result = Assert.Single(await service.GetMarketDataAsync("NSE", ["ABC"], true, 3));

        Assert.Equal(3, result.Candles.Count);
        Assert.Equal(result.Candles.Count, result.Candles.Select(candle => candle.Date.Date).Distinct().Count());
        Assert.Equal(today.AddDays(-2), result.Candles[0].Date.Date);
        Assert.Equal(today, result.Candles[^1].Date.Date);
    }

    [Fact]
    public async Task MarketData_SkipsTickerWithNoTradesOnBrokerTradingDate()
    {
        var today = DateTime.Today;
        var service = CreateMarketDataService(
            [CandleOn(today.AddDays(-3)), CandleOn(today.AddDays(-2)), CandleOn(today.AddDays(-1))],
            new LiveMarketResponse
            {
                LastUpdatedTime = today.AddHours(12),
                Quotes = [new LiveQuote { Ticker = "ABC", Open = 100, High = 100, Low = 100, LastPrice = 100, Volume = 0 }]
            });

        var result = Assert.Single(await service.GetMarketDataAsync("NSE", ["ABC"], true, 3));

        Assert.True(result.IsSkipped);
        Assert.Equal(MarketDataSkipReason.NoTradeToday, result.SkipReason);
    }

    [Fact]
    public async Task InsideBarLive_UsesPreviousSessionIfBrokerDateIsStale()
    {
        var today = DateTime.Today;
        var history = new Dictionary<string, List<MarketCandle>>
        {
            ["ABC"] = Candles(7)
                .Select((candle, index) =>
                {
                    candle.Date = today.AddDays(index - 7);
                    return candle;
                })
                .ToList()
        };
        var service = CreateInsideBarService(
            history["ABC"],
            new LiveMarketResponse { LastUpdatedTime = today.AddDays(-1) });

        var response = await service.GetAlertsAsync("NSE", "ABC", true);

        var result = Assert.Single(response.Data);
        Assert.Equal("EOD", result.EvaluationMode);
        Assert.False(result.IsProvisional);
        Assert.Contains("previous session", result.EvaluationMessage, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task InsideBarLive_SkipsTickerWithZeroVolumeToday()
    {
        var today = DateTime.Today;
        var history = new Dictionary<string, List<MarketCandle>>
        {
            ["ABC"] = Candles(7)
                .Select((candle, index) =>
                {
                    candle.Date = today.AddDays(index - 7);
                    return candle;
                })
                .ToList()
        };
        var service = CreateInsideBarService(
            history["ABC"],
            new LiveMarketResponse
            {
                LastUpdatedTime = today.AddHours(12),
                Quotes = [new LiveQuote { Ticker = "ABC", Open = 100, High = 102, Low = 98, LastPrice = 100, Volume = 0 }]
            });

        var response = await service.GetAlertsAsync("NSE", "ABC", true);

        var result = Assert.Single(response.Data);
        Assert.Equal("no_trade_today", result.EvaluationStatus);
        Assert.False(result.IsPatternDetected);
    }

    [Fact]
    public void Marubozu_RequiresLongBodyAndSmallUpperAndLowerShadows()
    {
        var candles = Enumerable.Range(0, 10)
            .Select(_ => Candle(99, 101, 98, 100))
            .Append(Candle(100, 109.5m, 99.5m, 109))
            .ToList();
        var detector = new MarubozuDetectionService(
            Options.Create(new MarubozuSettings()),
            NullLogger<MarubozuDetectionService>.Instance);

        var result = detector.Detect("ABC", candles, false);

        Assert.True(result.WhiteMarubozuDetected);
        Assert.Contains("WhiteMarubozu", result.MatchedPatterns);
    }

    [Fact]
    public void ThreeWhiteSoldiers_RequiresPriorDowntrendAndThreeRisingBullishCandles()
    {
        var candles = Candles(13);
        for (var i = 0; i < 10; i++)
        {
            var close = 110m - i;
            candles[i] = Candle(close - 0.5m, close + 0.5m, close - 1, close);
        }

        candles[10] = Candle(100, 102.2m, 99.8m, 102);
        candles[11] = Candle(101, 104.2m, 100.8m, 104);
        candles[12] = Candle(103, 106.2m, 102.8m, 106);
        var detector = new ThreeWhiteSoldiersDetectionService(
            Options.Create(new ThreeWhiteSoldiersSettings()),
            NullLogger<ThreeWhiteSoldiersDetectionService>.Instance);

        var result = detector.Detect("ABC", candles, false);

        Assert.Contains("ThreeWhiteSoldiers", result.MatchedPatterns);
    }

    private static TriangleSettings TriangleSettings() => new()
    {
        MinLookbackCandles = 20,
        EqualLevelPercent = 1m,
        SwingLeftBars = 2,
        SwingRightBars = 2,
        MinimumSwingHighs = 2,
        MinimumSwingLows = 2
    };

    private static int _nextDateOffset;

    private static MarketCandle Candle(decimal open, decimal high, decimal low, decimal close) => new()
    {
        Date = new DateTime(2026, 1, 1).AddDays(Interlocked.Increment(ref _nextDateOffset)),
        Open = open,
        High = high,
        Low = low,
        Close = close
    };

    private static List<MarketCandle> Candles(int count) => Enumerable.Range(0, count)
        .Select(i => new MarketCandle
        {
            Date = new DateTime(2026, 1, 1).AddDays(i),
            Open = 100,
            High = 102,
            Low = 98,
            Close = 100
        })
        .ToList();

    private static MarketCandle CandleOn(DateTime date) => new()
    {
        Date = date.Date,
        Open = 100,
        High = 102,
        Low = 98,
        Close = 100,
        Volume = 1
    };

    private static MarketDataService CreateMarketDataService(
        List<MarketCandle> history,
        LiveMarketResponse liveResponse)
    {
        var historyCache = new EodHistoryCache();
        historyCache.SetHistory("NSE", new Dictionary<string, List<MarketCandle>>
        {
            ["ABC"] = history
        });
        historyCache.MarkReady();

        return new MarketDataService(
            new OpenMarketStatusService(),
            historyCache,
            new FixedLiveMarketDataService(liveResponse),
            Options.Create(TriangleSettings()),
            new MarketAlertOptions(),
            NullLogger<MarketDataService>.Instance);
    }

    private static InsideBarNr7Nr4AlertService CreateInsideBarService(
        List<MarketCandle> history,
        LiveMarketResponse liveResponse) => new(
        CreateMarketDataService(history, liveResponse),
        new InsideBarNr7Nr4DetectionService(NullLogger<InsideBarNr7Nr4DetectionService>.Instance),
        Options.Create(new InsideBarNr7Nr4Settings()),
        new MarketAlertOptions { NseSymbols = ["ABC"] },
        NullLogger<InsideBarNr7Nr4AlertService>.Instance);

    private static SwingPoint Swing(int index, decimal price) => new()
    {
        Index = index,
        Date = new DateTime(2026, 1, 1).AddDays(index),
        Price = price
    };

    private static void SetTrend(List<MarketCandle> candles, int start, int end, bool rising)
    {
        for (var i = start; i < end; i++)
        {
            var close = rising ? 80m + i : 140m - i;
            candles[i].Open = close - 1;
            candles[i].Close = close;
            candles[i].High = close + 2;
            candles[i].Low = close - 2;
        }
    }

    private sealed class FixedSwingPoints(List<SwingPoint> highs, List<SwingPoint> lows) : ISwingPointService
    {
        public List<SwingPoint> FindSwingHighs(List<MarketCandle> candles, int leftBars, int rightBars) => highs;

        public List<SwingPoint> FindSwingLows(List<MarketCandle> candles, int leftBars, int rightBars) => lows;
    }

    private sealed class FakeBlockBulkDealRepository(
        DateOnly? date,
        List<BlockBulkDealRow> deals,
        Dictionary<string, decimal> shares) : IBlockBulkDealRepository
    {
        public DateOnly? RequestedDealDate { get; private set; }

        public Task<DateOnly?> GetLatestDealDateAsync(string exchange, CancellationToken cancellationToken = default) =>
            Task.FromResult(date);

        public Task<List<BlockBulkDealRow>> GetDealsAsync(string exchange, DateOnly dealDate, IReadOnlyList<string>? tickers, CancellationToken cancellationToken = default)
        {
            RequestedDealDate = dealDate;
            return Task.FromResult(dealDate == date ? deals : []);
        }

        public Task<Dictionary<string, decimal>> GetListedSharesAsync(string exchange, IReadOnlyList<string> tickers, CancellationToken cancellationToken = default) =>
            Task.FromResult(shares);
    }

    private sealed class FakeLongUnwindingRepository(LongUnwindingEodSnapshot snapshot) : ILongUnwindingRepository
    {
        public Task<LongUnwindingEodSnapshot> GetEodSnapshotAsync(
            string exchange,
            CancellationToken cancellationToken = default) =>
            Task.FromResult(snapshot);
    }

    private sealed class OpenMarketStatusService : IMarketStatusService
    {
        public Task<MarketStatus> GetMarketStatusAsync(string exchange, string segment, CancellationToken cancellationToken = default) =>
            Task.FromResult(new MarketStatus { Exchange = exchange, Segment = segment, Status = "OPEN", IsMarketOpen = true });
    }

    private sealed class FixedLiveMarketDataService(LiveMarketResponse response) : ILiveMarketDataService
    {
        public Task<LiveMarketResponse> GetLiveQuotesAsync(string exchange, CancellationToken cancellationToken = default) =>
            Task.FromResult(response);
    }
}
